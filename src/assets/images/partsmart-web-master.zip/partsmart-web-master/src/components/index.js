export { default as Header } from './header/header';
export { default as ProductCard } from './productCard/productCard';
export { default as Counter} from './counter/counter';